import lejos.nxt.UltrasonicSensor;

public class USController extends Thread {
	UltrasonicSensor usSensor;
	private int distance;
	private boolean stop;

	public USController( UltrasonicSensor us) {
		distance = -1;
		stop = true;
	}

	public void run() {
		stop = true;
		while (true) {
			
			if (stop) {
				usSensor.off();
				distance = -1;
				while(stop){
					//do nothing
				}
			}
				
			// process collected data
			distance = usSensor.getDistance();
			try {
				Thread.sleep(10);
			} catch (Exception e) {
			}
		}
	}

	public void stopUS() {
		stop = true;
	}
	
	public void restartUS(){
		stop = false;
	}

	public int sensorDist() {
		return distance;
	}

}
