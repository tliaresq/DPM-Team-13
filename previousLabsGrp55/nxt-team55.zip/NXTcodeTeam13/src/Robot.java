import lejos.nxt.ColorSensor;
import lejos.nxt.LCD;
import lejos.nxt.Motor;
import lejos.nxt.NXTRegulatedMotor;
import lejos.nxt.SensorPort;
import lejos.nxt.UltrasonicSensor;


public class Robot {
	public NXTRegulatedMotor leftMotor = Motor.A, rightMotor = Motor.B, armMotor = Motor.C;

	public UltrasonicSensor usLeftSensor = new UltrasonicSensor(SensorPort.S1), usRightSensor = new UltrasonicSensor(SensorPort.S2);

	public ColorSensor cs = new ColorSensor(SensorPort.S3);


	public double wwDist = 15.02;
	public double leftWradius = 2.08;
	public double rightWradius = leftWradius;
	public double lsDist = 8;

	public double black = 300; 		// raw output of a black line being detected.
	public double wallDist = 15; 		// distance the robot has to be from a wall when following it.

	public int defAcc = 700;
	public int defSpeed = 300;




	public Robot (){
		
		
		
	
	}

}
